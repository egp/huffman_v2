// tests/bb_smoke.rs v4

use huffman_v2::*;

#[test]
fn roundtrip_empty_input() {
    let input: &[u8] = b"";
    let encoded = encode(input);
    let decoded = decode(&encoded);
    assert_eq!(decoded, input);
}

#[test]
fn roundtrip_single_byte() {
    let input = b"a";
    let encoded = encode(input);
    let decoded = decode(&encoded);
    assert_eq!(decoded, input);
}

#[test]
fn deterministic_output_stub_level() {
    let input = b"hello hello hello";
    let e1 = encode(input);
    let e2 = encode(input);
    assert_eq!(e1, e2);
}

// -------- Frequency Table --------

#[test]
fn frequency_table_basic_counts() {
    let input = b"aab";
    let table = build_frequency_table(input);

    assert_eq!(table[b'a' as usize], 2);
    assert_eq!(table[b'b' as usize], 1);
}

// -------- Checksum --------

#[test]
fn checksum_known_vector_hello() {
    assert_eq!(checksum32(b"hello"), 0x4f9f2cab);
}

// -------- Frame Phase --------

#[test]
fn header_serialize_size() {
    let h = Header {
        flags: 0,
        original_size: 123,
        payload_size: 456,
    };

    let bytes = serialize_header(&h);

    assert_eq!(bytes.len(), HEADER_SIZE);
}

#[test]
fn header_roundtrip_debug() {
    let h = Header {
        flags: 0xAA,
        original_size: 0x1122334455667788,
        payload_size: 0x0102030405060708,
    };

    let bytes = serialize_header(&h);
    let parsed = parse_header(&bytes).unwrap();

    println!("ORIG: {:x?}", h);
    println!("PARSED: {:x?}", parsed);

    assert_eq!(parsed.flags, h.flags);
    assert_eq!(parsed.original_size, h.original_size);
    assert_eq!(parsed.payload_size, h.payload_size);
}

#[test]
fn header_rejects_bad_magic() {
    let mut bytes = vec![0u8; HEADER_SIZE];

    bytes[0..4].copy_from_slice(b"BAD!");

    let result = parse_header(&bytes);

    assert!(result.is_err());
}

#[test]
fn header_checksum_detects_corruption() {
    let h = Header {
        flags: 0,
        original_size: 1,
        payload_size: 1,
    };

    let mut bytes = serialize_header(&h);

    // flip one bit
    bytes[10] ^= 0x01;

    let result = parse_header(&bytes);

    assert!(result.is_err());
}

#[test]
fn header_serialize_writes_magic() {
    let h = Header {
        flags: 0,
        original_size: 123,
        payload_size: 456,
    };

    let bytes = serialize_header(&h);

    // Must be correct size
    assert_eq!(bytes.len(), HEADER_SIZE);

    // MUST write magic
    assert_eq!(&bytes[0..4], b"HUF1");
}

#[test]
fn header_writes_version() {
    let h = Header {
        flags: 0,
        original_size: 123,
        payload_size: 456,
    };

    let bytes = serialize_header(&h);

    assert_eq!(bytes.len(), HEADER_SIZE);

    // magic already enforced
    assert_eq!(&bytes[0..4], b"HUF1");

    // VERSION MUST BE 1
    assert_eq!(bytes[4], 1);
}

#[test]
fn header_writes_flags_bitfield() {
    let h = Header {
        flags: 0b0000_0001, // XOR flag ON (future use, but must serialize correctly)
        original_size: 123,
        payload_size: 456,
    };

    let bytes = serialize_header(&h);

    assert_eq!(bytes.len(), HEADER_SIZE);

    // magic
    assert_eq!(&bytes[0..4], b"HUF1");

    // version
    assert_eq!(bytes[4], 1);

    // flags MUST be preserved exactly
    assert_eq!(bytes[5], 0b0000_0001);
}

#[test]
fn header_writes_original_size_le() {
    let h = Header {
        flags: 0,
        original_size: 0x1122334455667788,
        payload_size: 0,
    };

    let bytes = serialize_header(&h);

    assert_eq!(bytes.len(), HEADER_SIZE);

    // HARD CHECK: fixed header identity
    assert_eq!(&bytes[0..4], b"HUF1");
    assert_eq!(bytes[4], 1);
    assert_eq!(bytes[5], 0);

    // checksum field must be present and consistent (not assumed zero)
    let mut tmp = bytes.clone();
    tmp[6..10].fill(0);

    let mut chk = [0u8; 4];
    chk.copy_from_slice(&bytes[6..10]);

    assert_eq!(
        u32::from_le_bytes(chk),
        crate::checksum32(&tmp),
        "checksum mismatch"
    );

    // must NOT be all-zero header (sanity check)
    assert!(
        !bytes.iter().all(|&b| b == 0),
        "header is still uninitialized stub"
    );

    // STRICT CHECK: original_size encoding
    let expected = 0x1122334455667788u64.to_le_bytes();
    assert_eq!(&bytes[10..18], &expected);
}

#[test]
fn debug_dump_header_bytes() {
    let h = Header {
        flags: 0xAA,
        original_size: 0x1122334455667788,
        payload_size: 0x0102030405060708,
    };

    let bytes = serialize_header(&h);

    println!("{:02x?}", bytes);

    // force visibility in CI logs
    assert_eq!(bytes.len(), HEADER_SIZE);
}

#[test]
fn header_writes_checksum_field() {
    let h = Header {
        flags: 0xAA,
        original_size: 0x1122334455667788,
        payload_size: 0x0102030405060708,
    };

    let bytes = serialize_header(&h);

    assert_eq!(bytes.len(), HEADER_SIZE);

    // sanity checks
    assert_eq!(&bytes[0..4], b"HUF1");
    assert_eq!(bytes[4], 1);

    // checksum field must NOT be zero (once implemented)
    let mut tmp = bytes.clone();
    tmp[6..10].fill(0);

    let mut chk = [0u8; 4];
    chk.copy_from_slice(&bytes[6..10]);
    let checksum = u32::from_le_bytes(chk);

    assert_eq!(checksum, crate::checksum32(&tmp));
}

#[test]
fn frame_header_type_exists() {
    let frame_type = FrameType::Header;

    assert_eq!(frame_type as u8, 0);
}

#[test]
fn frame_basic_pack_and_unpack() {
    let payload = vec![1u8, 2, 3, 4];

    let frame = frame::pack(FrameType::Header, &payload);
    let (t, out) = frame::unpack(&frame).unwrap();

    assert_eq!(t, FrameType::Header);
    assert_eq!(out, payload);
}

#[test]
fn frequency_table_frame_roundtrip() {
    let mut table = [0u32; 256];
    table[65] = 10;
    table[66] = 20;

    let mut payload = Vec::new();
    for v in table.iter() {
        payload.extend_from_slice(&v.to_le_bytes());
    }

    let frame = frame::pack(FrameType::FrequencyTableInternal, &payload);
    let (t, out) = frame::unpack(&frame).unwrap();

    assert_eq!(t, FrameType::FrequencyTableInternal);

    let mut decoded = [0u32; 256];
    for i in 0..256 {
        let mut b = [0u8; 4];
        b.copy_from_slice(&out[i * 4..i * 4 + 4]);
        decoded[i] = u32::from_le_bytes(b);
    }

    assert_eq!(decoded[65], 10);
    assert_eq!(decoded[66], 20);
}

#[test]
fn frequency_table_external_frame_roundtrip() {
    let name = "wikipedia_en";

    let payload = name.as_bytes();

    let frame = frame::pack(FrameType::FrequencyTableExternal, payload);
    let (t, out) = frame::unpack(&frame).unwrap();

    assert_eq!(t, FrameType::FrequencyTableExternal);
    assert_eq!(out, payload);

    assert_eq!(std::str::from_utf8(&out).unwrap(), name);
}

#[test]
fn frequency_table_internal_must_be_fixed_size() {
    let payload = vec![0u8; 1024];

    let frame = frame::pack(FrameType::FrequencyTableInternal, &payload);
    let (_, out) = frame::unpack(&frame).unwrap();

    assert_eq!(out.len(), 1024);
}

#[test]
fn frequency_table_internal_rejects_wrong_size() {
    let bad_payload = vec![0u8; 100]; // invalid

    let frame = frame::pack(FrameType::FrequencyTableInternal, &bad_payload);

    let result = frame::unpack(&frame);

    assert!(result.is_err());
}

#[test]
fn huffman_tree_builds_deterministically() {
    let mut freq = [0u32; 256];
    freq[65] = 5;
    freq[66] = 5;
    freq[67] = 10;

    let tree1 = huffman::build_tree(&freq);
    let tree2 = huffman::build_tree(&freq);

    assert_eq!(tree1, tree2);
}

#[test]
fn huffman_codes_are_deterministic() {
    let mut freq = [0u32; 256];
    freq[65] = 5;
    freq[66] = 5;
    freq[67] = 10;

    let tree = huffman::build_tree(&freq);
    let codes1 = huffman::build_codes(&tree);
    let codes2 = huffman::build_codes(&tree);

    assert_eq!(codes1, codes2);
}

#[test]
fn encoder_produces_deterministic_bitstream() {
    let mut freq = [0u32; 256];
    freq[65] = 5;
    freq[66] = 5;

    let tree = huffman::build_tree(&freq);
    let codes = huffman::build_codes(&tree);

    let input = vec![65u8, 66u8, 65u8];

    let encoded = huffman::encode_stream(&input, &codes);

    let encoded2 = huffman::encode_stream(&input, &codes);

    assert_eq!(encoded, encoded2);
}

#[test]
fn huffman_roundtrip_reconstructs_input() {
    let mut freq = [0u32; 256];
    freq[65] = 5;
    freq[66] = 5;
    freq[67] = 10;

    let tree = huffman::build_tree(&freq);
    let codes = huffman::build_codes(&tree);

    let input = vec![65u8, 66, 65, 67, 66];

    let encoded = huffman::encode_stream(&input, &codes);
    let decoded = huffman::decode_stream(&encoded, &tree, input.len());

    assert_eq!(decoded, input);
}

#[test]
fn frame_codec_roundtrip_internal_table() {
    let input = b"hello hello hello";

    let encoded = encode(input);
    let decoded = decode(&encoded);

    assert_eq!(decoded, input);
}

// tests/bb_smoke.rs v4
