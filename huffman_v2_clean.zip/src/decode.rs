// src/decode.rs v2
use crate::huffman::{decode_stream, BitReader, Node};

pub fn decode(input: &[u8]) -> Vec<u8> {
    if input.is_empty() {
        return Vec::new();
    }

    // build tree (CURRENT CONTRACT: tuple)
    let (tree, root) =
        crate::huffman::build_tree(&crate::huffman::build_frequency_table(&input[4..]));

    // SAFETY: ensure we have a root
    let root_idx = match root {
        Some(r) => r,
        None => return Vec::new(),
    };

    // debug (optional, but stable)
    eprintln!("decode input len = {}", input.len());
    eprintln!("tree len = {}", tree.len());

    // IMPORTANT: pass expected bit length from BitReader convention
    let mut reader = BitReader::new(input);
    let expected_len = reader.remaining_bits;

    decode_stream(&mut reader, &tree, root_idx, expected_len)
}

// src/decode.rs v2
